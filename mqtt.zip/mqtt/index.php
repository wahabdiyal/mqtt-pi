<?php
 
declare(strict_types=1);

require __DIR__ . "/vendor/autoload.php";

 
use PhpMqtt\Client\Exceptions\MqttClientException;
use PhpMqtt\Client\MqttClient;
use Psr\Log\LogLevel;
use Psr\Log\AbstractLogger;
use Psr\Log\LoggerInterface;
 

class SimpleLogger extends AbstractLogger implements LoggerInterface
{
    /** @var string */
    private $logLevel;

    /** @var int */
    private $logLevelNumeric;

    /**
     * SimpleLogger constructor.
     *
     * @param string|null $logLevel
     */
    public function __construct(string $logLevel = null)
    {
        if ($logLevel === null) {
            $logLevel = LogLevel::DEBUG;
        }

        $this->logLevel        = $logLevel;
        $this->logLevelNumeric = $this->mapLogLevelToInteger($logLevel);
    }

    /**
     * Logs with an arbitrary level.
     *
     * @param mixed  $level
     * @param string $message
     * @param array  $context
     * @return void
     */
    public function log($level, $message, array $context = []): void
    {
        if ($this->mapLogLevelToInteger($level) < $this->logLevelNumeric) {
            return;
        }

        echo $this->interpolate($message, $context) . PHP_EOL;
    }

    /**
     * Interpolates the given message with variables from the given context.
     * Replaced are placeholder of the form {foo} with variables of the same
     * name without curly braces in the context.
     *
     * @param       $message
     * @param array $context
     * @return string
     */
    private function interpolate($message, array $context = [])
    {
        // Build a replacement array with braces around the context keys.
        $replace = [];
        foreach ($context as $key => $val) {
            // Ensure that the value can be cast to string.
            if (!is_array($val) && (!is_object($val) || method_exists($val, '__toString'))) {
                $replace['{' . $key . '}'] = $val;
            }
        }

        // Interpolate replacement values into the message and return the result.
        return strtr($message, $replace);
    }

    /**
     * Maps the string representation of a log level to the numeric level.
     *
     * @param string $level
     * @return int
     */
    private function mapLogLevelToInteger(string $level): int
    {
        $map = $this->getLogLevelMap();

        if (!array_key_exists($level, $map)) {
            return $map[LogLevel::DEBUG];
        }

        return $map[$level];
    }

    /**
     * Returns a log level map.
     *
     * @return array
     */
    private function getLogLevelMap(): array
    {
        return [
            LogLevel::DEBUG     => 0,
            LogLevel::INFO      => 1,
            LogLevel::NOTICE    => 2,
            LogLevel::WARNING   => 3,
            LogLevel::ERROR     => 4,
            LogLevel::CRITICAL  => 5,
            LogLevel::ALERT     => 6,
            LogLevel::EMERGENCY => 7,
        ];
    }
}

define('MQTT_BROKER_HOST', '127.0.0.1');
define('MQTT_BROKER_PORT', 1883);
define('MQTT_BROKER_TLS_PORT', 8883);

define('TLS_SERVER_CA_FILE', '');
define('TLS_CLIENT_CERTIFICATE_FILE', '');
define('TLS_CLIENT_CERTIFICATE_KEY_FILE', '');
define('TLS_CLIENT_CERTIFICATE_KEY_PASSPHRASE', null);

define('AUTHORIZATION_USERNAME', '');
define('AUTHORIZATION_PASSWORD', '');
// Create an instance of a PSR-3 compliant logger. For this example, we will also use the logger to log exceptions.
$logger = new SimpleLogger(LogLevel::INFO);

try {
    // Create a new instance of an MQTT client and configure it to use the shared broker host and port.
    $client = new MqttClient(MQTT_BROKER_HOST, MQTT_BROKER_PORT, 'test-subscriber', MqttClient::MQTT_3_1, null, $logger);

    // Connect to the broker without specific connection settings but with a clean session.
    $client->connect(null, true);

    // Subscribe to the topic 'foo/bar/baz' using QoS 0.
    $client->subscribe('esp8266', function (string $topic, string $message, bool $retained) use ($logger, $client) {
        $logger->info('We received a {typeOfMessage} on topic [{topic}]: {message}', [
            'topic' => $topic,
            'message' => $message,
            'typeOfMessage' => $retained ? 'retained message' : 'message',
        ]);

        // After receiving the first message on the subscribed topic, we want the client to stop listening for messages.
        $client->interrupt();
    }, MqttClient::QOS_AT_MOST_ONCE);

    // Since subscribing requires to wait for messages, we need to start the client loop which takes care of receiving,
    // parsing and delivering messages to the registered callbacks. The loop will run indefinitely, until a message
    // is received, which will interrupt the loop.
    $client->loop(true);

    // Gracefully terminate the connection to the broker.
    $client->disconnect();
} catch (MqttClientException $e) {
    // MqttClientException is the base exception of all exceptions in the library. Catching it will catch all MQTT related exceptions.
    $logger->error('Subscribing to a topic using QoS 0 failed. An exception occurred.', ['exception' => $e]);
}
